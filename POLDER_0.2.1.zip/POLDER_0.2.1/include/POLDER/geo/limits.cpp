////////////////////////////////////////////////////////////
///
/// POLDER Geo - POLDER library defining the limits for margin errors
/// Written by Morwenn Edrahir, 2011
///
////////////////////////////////////////////////////////////

#include "limits.h"


namespace polder
{
namespace geo
{


// Get the margin error
double margin_error()
{
    return geo_margin_error;
}

// Set the margin error
void set_margin_error(double error)
{
    geo_margin_error = error;
}

// Reset the margin error
void reset_margin_error()
{
    geo_margin_error = std::numeric_limits<double>::epsilon() * 10;
}

// Compare two doubles taking in account the marging error
bool round_equal(double a, double b)
{
    return fabs(a-b) < geo_margin_error;
}


} // namespace geo
} // namespace polder
